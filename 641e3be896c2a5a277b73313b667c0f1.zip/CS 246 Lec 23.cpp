// Recall - dynakmic casting on references:

Text t {...};
Book &b = t;
Text &t2 = dynamic_cast<Text &>(b);
// If it fails: raises exception bad-cast

// Can use this to solve the polymorphic assignment problem:

Text &Text::operator=(const Book &b) { // Virtual
	Text &textother = dynamic_cast<Text &>(b); // Throws an exception if other is not a Text
	if (this == &textother) return *this;
	Book::operator=(other);
	topic = textother.topic;
	return *this;
}

// How Virtual methods work
class Vec {
	int x,y;
	public:
		void doSomething();
};

class Vec2 {
	int x,y;
	public:
		virtual void doSomething();
};

// What's the difference?
Vec v {1,2};
Vec2 w {1,2}; // Do they look the same in memory?
// See if they have the same size
cout << sizeof(v) << " " << sizeof(w);
// We get 8 and 16 respectively
// First note: 8 = space for 2 ints
// No space for the doSomething method
// Methods do not actually stored inside the object, even though it is written in the class
// Otherwise, every object would have its own method
// Compiler turns methods into ordinary functions & stores them separately from objects

// Recall:
Book *pb = new (Book or Text or Comic)
pb->isItHeavy();
// isItHeavy is virtual - choice of which version of isItHeavy to run is based on the type of the actual object - 
// which the compiler can't know in advance (What if it was made with factory method, etc.)
// Therefore, correct isItHeavy must be chosen at run-time. How? 
// For each class with virtual methods, the compiler creates a table of function ptrs (the vtable)
// Eg:
class C {
	int x,y;
	virtual void f();
	virtual void g();
	void h();
	virtual ~C();
};

C c,d;

/*
vtable
["C"]	<-------------
[ f ] -> f[...]		 |
[ g ] -> g[...]		 |
[ ~C ] -> ~C[...]	 |
					 |
c[x,y,vptr]--------- |
					 |
d[x,y,vptr]----------|
*/
// C objects have an extra ptr (the vptr) that points to C's vtable

/* Eg:
Book b;
[title]
[author]
[numPages]
[vptr]------> ["Book"]
			  [isItHeavy] -> Book::isItHeavy
							 [Code for Book::isItHeavy()]
			  
Text t;
[title]
[author]
[numPages]
[topic]
[vptr] -------> ["Text"]
				[isItHeavy] -> Text::isItHeavy
							   [Code for Text::isItHeavy()]
*/
/* If Text didn't override isItHeavy(), then:
["Text"]
[isItHeavy] -> [Book::isItHeavy]
			   [Code for Book::isItHeavy()] 
instead.
*/

/* Calling a virtual method:
- follow vptr to vtable
- fetch ptr to actual method from the table
- follow the function ptr and call the function
Happens at run-time
*/

// Therefore, virtual methods calls incur a small overhead cost (in time and space)
// Also: declaring at least one virtual method adds a vptr to the object
// Therefore, classes with no virtual methods produce smaller objects than if some methods were virtual

// vtables are labelled with names so that dynamic_cast knows what type an object is (Can be expensive)
// as opposed to static_cast, which is cheap
// That's why dynamic_cast requires at least one virtual method

// Concretely, how is an object laid out? Compiler dependent.

/* g++ places vptr first:
	   [vptr]
fields [...]
*/
class A {
	int a,c;
	virtual void f();
};
/* In memory:
[vptr]
[a]
[c]
*/
class B: public A{
	int b,d;
}
/* In memory:
[vptr]
[a]
[c]
[b]
[d]
*/

// If b is sliced, still looks like A.
// or if I have a pointer pointing at B, it still looks like a pointer to A, if you ignore the last two fields
// we get "is a" property for free
// Suppose we don't know what the object is, we wouldn't know where the vptr is, can't dynamic_cast either b/c we have no vptr, vtable

// Multiple Inheritance
// A class can inherit from >1 parent

class A {
	public:
		int a;
};

class B {
	public:
		int b;
};

class C: public A, public B {
	void f() {
		cout << a << " " << b;
	}
}; // Like assn 4, cell was a subject and an observer

// Challenges:
/*
[A]			[A]
[+a]		[+a]
 ^			 ^
inherits	inherits
 |			 |
 |			 |
[B]			[C]
[+b]		[+c]
 ^			 ^
 |			 |
 -------------
	   |
	  inherits
	   |
	  [D]
	  [+d]
B, C inherit from A
*/

class D: public B, public C {
	public:
		int d;
};

D d;
d.a;
// which a is this?
// We get a compiler error - ambiguous
// Compiler means if we mean int A::a ... or int A::a since both B and C inherit from A
// We must disambiguate:
d.B::a // or 
d.C::a
// But if B & C inherit from A, should there be one A part of D, or two? (Which is the default)
// in other words for this example, should B::a, C::a be the same, or different?
// What if we want:
/*
	[A]
	/ \
   [B][C] "Deadly Diamond"
    \  /
	[D]
*/

// Make A a virtual base class, employ virtual inheritance
class B: virtual public A {...};
class C: virtual public A {...};
/* Occurs in the IO stream hierarchy:
		ios_base Flags are up here
			|
		   ios
		  /	  \
	virtual	virtual
		|		|
	istream		ostream
	   |  			|
		\			/
		  iostream
			  |
			fstream
	   |	stringstream  |
istringstream		ofstream
ifstream			ostringstream

ifstringstream, ifstream inherit from istream
ofstream, ostringstream inherit from ostream
iostream inherits from istream and ostream
*/

// How will this be laid out in memory? 
/* where v = virtual
	[A]
	v/ \v 
   [B][C] "Deadly Diamond"
    \  /
	[D]

[vptr] <- same ptr should like like an A*, B*, C*, D*)
[Afields]
[Bfields]
[Cfields]
[Dfields]

This doesn't look like a C pointer, so it won't work

What does g++ do? Check virtual.cc
[vptr] <- appears to look like ptr to B - But not really (Same for C)
[Bfields]
[vptr] <- appears to look like ptr to C
[Cfields]
[Dfields]
[vptr] <- ptr to A
[Afields]
Only slices of the object appear to look like the actual desired object

if we have B b;
expect to see:
[vptr]
[Bfields]
[vptr]
[Afields]

Not what we have above
We conclude that the distance from a class to its base class isn't always the same
So how would you find out where your superclass is?
Solution: vtable tells you how to find your superclass
Store length to superclass in vtable
*/
D d;
A *a = &d; // Pointer a will not have the same value as the actual address of d
// Compiler will shift pointer value down 