// Rvalues of Rvalue References

// Recall: An lvalue is anything with an address
// An lvalue reference (&) is like a const. ptr with auto-deref - always initalized to an lvalue
Node n {1, new Node {2, nullptr}};
Node m = n; // copy ctor.
Node m2;
m2 = n; // Copy assignment operator

Node plusOne(Node n) {
	for (Node *p = &n; p; p=p->next) {
		++p->data;
	}
	return n;
}
Node m3 = plusOne(n); // Copy ctor
// What is "other" at "plusOne(n)?" Reference to what?

// Compiler creates a temporary object to hold the result of plusOne
// other is a reference to this temporary
// - copy ctor deep copies the data from this temporary
// BUT - the temp. is going to be discarded as soon as
Node m3 = plusOne(n); // is done
// Wasteful to copy data from a temp - why not just steal it instead
// Save the cost of a copy
// Need to be able to tell whether other is a reference to a temporary or standalone object

// C++ - rvalue reference Node&& is a reference to a temporary object (rvalue) of type Node

// Version of the ctor that takes a Node&&:
struct Node {
	...
	Node (Node &&other): // Move ctor, what should it do? (steal other's data)
		data {other.data},
		next {other.next} {
			other.next = nullptr; // So the list is not lost when other is destroyed
		}
}

// Similarly: 
Node m;
m = plusOne(n) // Assignment from temporary

// Move assignment operator:
struct Node {
	...
	Node &operator=(Node &&other) { // steal other's data, destroy my old data, swap without copy
		swap(other);
		return *this;
		// temp destroyed and take our old data with it
	}
}

// If you don't define move/ctor/assignment, the copy versions will be used
// If you do define them, they replace all calls to copy ctor/assignment when the argument is a temporary (rvalue)

// Copy/Move Elision
Vec makeAVec() {
	return {0,0}; // invokes a basic ctor
}
Vec v = makeAVec(); // What runs, copy or move ctor?
// Not sure - In g++: just the basic ctor. No copy/move ctor

// In some circumstances, the compiler is allowed to skip calling copy/move ctors (but doesn't have to)
// In our example: makeAVec writes its result ({0,0}) directly into the space occupied by v in the caller, rather than copy/move later

// Example:
void doSomething(Vec v) // calls copy/move ctor 
{...}
doSomething(makeAVec());
// result of makeAVec() is written directly into the parameter, no move/copy
// This is allowed even if dropping ctor calls would change the behavious of the program (eg if the ctors print something)

// Not expected to know exactly when copy/move elision is allowed - just that it is a possibility
// If you need all the ctors to run:
g++14 -f-no-elide-constructors
// This can slow down your program considerably (Enables every constructor in your program)

// In summary: Rule of 5 (Big 5)
// If you need to customize any one of
// copy ctor, copy assignment, dtor, move ctor, move assignment 
// then you usually need to customize all 5

// Notice: operator= is a member function, not a standalone function
// When an operator is defined as a member function, "this" plays the role of the first arg
struct Vec {
	int x, y;
	... 
	Vec operator+(const Vec &other) {
		return {x + other.x, y + other.y};
	} Vec operator *(const int k) {return {k*x, k*y}}; // implements v*k
};
// To implement k*v - can't be a member function, first arg is not vec.
Vec operator * (const int k, const Vec &v) {
	return v*k;
}

// I/O operators:
struct Vec {
	...
	ostream &operator << (ostream &out) {
		return out << x << ' ' << y	;
	}
};

// What's wrong? Makes Vec ther first argument, so use as v << cout;

// So define operator <<, >> as standalones
// Certain operators must be members:
// operator=
// operator[]
// operator->
// operator()
// operator T (Where T is a type)

// Separate Compilation for Classes 
// Node.h
# ______
struct Node {
	int data;
	Node *next;
	explicit Node (int data, Node *next=nullptr);
	bool hasNext();
};
#endif

// Node.cc
#include "Node.h"
Node(int data, Node *next): data{data}, next{next}{} // Won't compile, thinks we're writing smth next
// To fix: 
#include "Node.h"
Node::Node(int data, Node *next): data{data}, next{next}{}
bool hasNext(){return next != nullptr;}

// :: - called the scope resolution operator
Node::______ means _______ in the context of struct Node
:: like . where LHS is a class (or namespace), not an object