// Classes
// Can put functions inside structs
// Ex: 
struct student {
	int assns, mt, finals;
	float grade () {
		return assns * 0.4 + mt * 0.2 + finals * 0.4
	}
};

...
student s {60, 70, 80};
cout << s.grade() << endl;

// class - a struct type that can contain functions 
// C++ - has a class keyword which we will use later
// Object - an instance of a class
// Ex: Student s {60, 70, 80};
// Student is a class, s is an object

// Function grade - called a member function, or a method
// What do assns, mt, final mean inside of grade(){...}?
// They are fields of the current object upon which grade() was invoked
Student billy {...}
billy.grade(); // Method call, uses Billy's assns, mt, final

// Formally, methods take a hidden extra parameter called this
// this is a ptr to the object upon which the method was called
// Ex:
billy.grade(); // () this == &billy
// Can write: 
struct student {
	float grade() {
		return this->assns*0.4 + this->mt*0.2 + this->finals*0.4;
	}
}

// Initializing Objects
Student billy {60, 70, 80}; // Ok, but limited
// Better: Write a method that does initialization: a constructor (ctor)
struct student {
	int assns, mt, finals;
	float grade() {...}
	Student (int assns, int mt, int finals) {
		// Doesn't work, assigning parameters to themselves and doing nothing
		assns = assns;
		mt = mt;
		finals = finals;
	}
}
// To fix: 
struct student {
	int assns, mt, finals;
	float grade() {...}
	Student (int assns, int mt, int finals) {
		// Doesn't work, assigning parameters to themselves and doing nothing
		this->assns = assns;
		this->mt = mt;
		this->finals = finals;
	}
}

Student billy {60, 70, 80}; // better
// if a ctor has been defined, these are passed as args to the ctor
// if no ctor has been defined, these initialize the individual fields of Student (c-style)
// OR
Student billy = Student {60, 70, 80};
// Heap Allocation (As opposed to stack):
Student *pBilly = new Student {60, 70, 80};

// Advantage of ctors: default params, overloading, sanity checks
// Ex:
struct Student {
	...
	Student (int assns = 0, int mt = 0, int finals = 0) {
		this->assns=assns;
		...
	}
};
Student jane = {70, 80}; // 70, 80, 0
Student newKid; // 0, 0, 0

// Note: Every class comes with a default constructor (i.e. no-arg) ctor
// (Which just default-constructs all fields that are objects)
// Ex:
Vec v; // default ctor (does nothing in this case since fields are ints)
// But the built in default ctor goes away if you provide a constructor
// Ex:
struct Vec{
	int x,y;
	Vec (int x, int y) {
		this->x = x;
		this->y = y;
	}
};
... 
Vec v {1,2}; //OK
Vec v; // Can't do this, no default contructor

// What if a constructor contains consts or refs?
struct MyStruct {
	const int myConst;
	int &myRef;
};
// They must be initialized
int z;
struct MyStruct {
	const int myConst = 5;
	int &myRef = z;
};
// But does every instance of myStruct need to have the same value of myConst and myRef (which is a constant ptr)?
// Ex:
struct Student {
	const int id; // Constant (doesn't change) but not the same for all students
	...
};
// Where do we initialize? ctor body? - too late, fields must be fully constructed by then
// What happens when an object is created?
// 1) Space is allocated
// 2) Fields are constructed (We need to put our initializations here)
// 3) ctor body runs
// How? -member initialization list (MIC)
struct Student {
	const int id;
	int assns, mt, finals;
	Student (int id, int assns, int mt, int finals):
		id {id}, assns{assns}, mt{mt}, finals{finals}{}
		// id, assns, etc. have to be your fields
		// {params} can be any expression you want
};
// Note: You can initialize any field this way, not just consts and refs
// Note: fields initialized in the order in which they were declared in the class, even if the MIL orders them differently
// Note: MIL sometimes more efficient than setting fields in ctor body 
// (o/w - run default ctor, then reassign in the body)
// What if a field is initialized inline AND in the MIL?
struct Vec {
	int x=0, y=0;
	Vec(int x): x{x}{}
};
// MIL takes precedence
// Now consider:
Student billy {60, 70, 80};
Student bobby = billy; // How does this initialization happen? 
// The copy constructor, for constructing one object as a copy of another 
// NB: Streams don't have a copy constructor, can't be copied

// Note: Evevry class comes with
// -a default ctor (default - constructs all fields that are objects)
// lost if you define any ctor
// - a copy ctor (just copies all fields)
// - a destructor
// - a move ctor
// - a move assignment operator

// Building your own copy ctor: 
struct Student {
	int assns, mt, finals;
	Student (...){...}
	Student (const Student &other):
		assns{other.assns}, mt{other.mt}, finals{other.finals}{}
};
// Equiv to built in copy ctor
// When is the built-in copy ctor not correct?
// Consider:
struct Node {
	int data;
	Node *next;
	Node (int data, Node *next):
		data{data}, next{next}{}
};
Node *n = new Node {1, new Node{2, new Node {3, nullptr}}};
// These two both copy ctor
Node m = *n;
Node *p = new Node {*n}

// Memory 
stack			Heap
n[]-------------> [1][-]>[2][-]>[3][\]
m[1][-]-------------------^ // points to 2
p[-]>[1][-]---------------^ // Also points to 2
// Simple copy of fields => only the first node is actually copied (Shallow copy)
// If you want a deep copy (copies the whole list), must write your own copy ctor