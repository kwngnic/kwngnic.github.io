// Measures of Design Quality

// Coupling and cohesion

/* Coupling: the degree to which distinct program modules depend on each other
Low Coupling: 
- Modules communicate via function calls w/ basic params/results
- Modules pass arrays/structs back and forth
- Modules affect each other's control flow
- Modules share global data

High Coupling:
- Modules have access to each other's implementation (friends)
*/

/* Cohesion - how closely elements of a module are related to each other
Low Cohesion:
- Arbitrary grouping of unrelated elements (Eg. <utility>)
- Elements share a common theme, but otherwise unrelated - perhaps share some base code (Eg. <algorithm>)
- Elements manipulate state over the lifetime of an object (Eg. open/read/close files)
- Elements pass data to each other

High Cohesion:
- Elements cooperate to perform exactly one task
*/

/* High Coupling
- Changes to one module require greater changes to other modules
- Harder to reuse individual modules

Low Cohesion
- Poorly organized code
- Hard to understand, hard to maintain
- Goal: Low coupling, high cohesion
*/

// Decoupling the Interface (MVC)
// Your primary program classes shouldn't be printing things
// Ex:
class ChessBoard {
	...
	cout << "Your move" << endl;
};
// Bad Design - Inhibits code reuse
// What if you want to reuse ChessBoard, but not have it communicate via stdout?
// One solution: Give the class stream objects to read from / write to

class ChessBoard {
	istream &in;
	ostream &out;
	public:
		ChessBoard(istream &in, ostream &out): istream{in}, ostream{out} {}
		...
		out << "Your move" << endl;
};

// Better - but what if we don't want to use streams at all?
// Your chessboard class should not be doing any communication at all

// Single Responsibility Principle: "A class should have only one reason to change."
// - Game state & communication are TWO reasons
// Better: Communicate with the chessboard via params, results
// - Confine user communication to outside the game class

// Q: Should main do lal of the communication & then call chessboard methods?
// A: No - Hard to reuse code if it's in main, should have a class to manage interaction that is separate
// from the game state class

// Pattern: Model-View-Controller (MVC)
// Separate the distinct notions of
// Model - the data you are manipulating (ie. the game state)
// View - how the model is displayed to the user
// Controller - How the model is manipulated
/*
[Model] ---- [View] // --- represents "sometimes" depending on interpretation of MVC
	 |		  |
	[Controller]
Model - can have multiple views (Eg. Text & Graphics)
- doesn't need to know about their details
- classic Observer pattern (or could communicate via controller)

Controller - mediate control flow through model & view
- may encapsulate turn-taking or full game rules
- may fetch user input (or this could be the view)	
- By decoupling presentatation & control, MVC promotes reuse.
*/

// Exception Safety
// Consider

void f() {
	MyClass *p = new MyClass;
	MyClass mc;
	g();
	delete p;
}
// No leaks - what if g raises an exception? What is guaranteed?
// During stack-unwinding, all stack-allocated data is cleaned up - dtors run, memory is reclaimed
// Therefore, mc is reclaimed
// Heap-allocated memory is not deleted
// Therefore, if g throws, p is leaked

void f() {
	MyClass *p = *new MyClass;
	MyClass mc;
	try {
		g();
	}
	catch(...) { // Again, ... catches everything
		delete p;
		throw;	// So that someone further up can handle the problem
	}
	delete p; // So that if g() doesn't throw we don't leak
}

// the try/catch block is tedious & error prone - also has code duplication (delete p)
// how else can we guarantee that something (Ex. delete p) 
// will happen no matter how we exit f (normally or by exeption?)
// In some languages - "finally" clauses guarantee certain final actions - not in C++
// Only one thing you can count on in C++ - dtors for stack allocated data will run 
// Therefore, use stack-allocated data with dtors as much as possible
// Use this guarantee to your advantage

// C++ idiom: RAII - Resource Acquisition Is Initialization
// Every resource should be wrapped in a stack-allocated object, whose dtor frees it
// Ex: files  
{ifstream f {"name"}; // Acquiring the resource "name" = initializing the object (f)
// The file is guaranteed to be released when f is popped from the stack (f's dtor runs) Ex: XWindow class from a4
}

// This can be done with dynamic memory:
class std::unique_ptr<T> // Takes a T* in the ctor
// The dtor will delete the ptr 
// - in between - can dereference just like a ptr

void f() {
	auto p = std::make_unique<MyClass>(); // Can place ctor arguments in () if needed
	MyClass mc;
	g();
} // No leaks, guaranteed