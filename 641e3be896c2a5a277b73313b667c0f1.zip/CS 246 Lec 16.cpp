// Now consider:
void f() {
	throw.out_of_range{"f";} // Constructor call - creates an object of type out_of_range & throw it
		// {"f"} is what() function threw the exception
}

void g() {f();}
void h() {g();}
int main(){
	try {
		h();
	}
	catch (out_of_range){...}
}
/* What happens:
main calls h 
h calls g
g calls f
f throws
g has no handler for out_of_range
Control goes back through the call chain (unwinds the stack) until a handler is found
Control goes all the way to main, which handles the exception
If no handler in the entire call chain, program terminates
*/

// What is out_of_range? -A class 
throw out_of_range{"f"} //- ctor call
// A handler could do part of the recovery job - execute some corrective code and throw another exception
try {...}
catch (someErrorType s){
	...
	throw someOtherError{...}
}
// or throw the same exception
try {...}
catch (someErrorType s) {
	...
	throw;
}

// throw vs throw s
/* [someErrorType]
         ^
         |
   [specialErrorType]
*/
// s may have originated as a subclass of someErrorType
// throw s - throws a new exception of type someErrorType
// throw - actual type of s is retained

// A handler can act as a catch-all
try {___}
catch (...) { // Catches all exceptions - the ... are not placeholder
	___
}
// You can throw anything you want
// You don't have to throw objects

// Define your own exception classes
class BadInput {};
try {
	int n;
	if (!(cin>>n)) throw BadInput{};
}
class ReallyBadInput: public BadInput{} {}

catch (BadInput &) { // catching exception by reference, just like pass by value, catch by value also slices
// Catching ReallyBadInput will throw BadInput(); b/c of slicing
// Slicing occurs when you catch and when you rethrow
// throw; throws by reference
	cerr << "___" << endl;
}

// Exception std::bad_alloc - thrown when new fails

// Design Patterns ctd
// Guiding principle: program to the interface, not the implementation
// Abstract base classes define the interface
// Work with ptrs to abstract base classes, and call their methods 
// Concrete subclasses can be swapped in and out 
// abstraction over a variety of behaviours

// Eg: Iterator pattern:
class List {
	...
	public:
		class Iterator: public AbstractIterator { // inherited from below, does nothing for now
			...
		};
	...
};

class AbstractIterator {
	public:
		virtual int &operator *() = 0;
		virtual AbstractIterator &operator++() = 0;
		virtual bool operator!=(const AbstractIterator &other) = 0;
		virtual ~AbstractIterator();
};

class Set {
	...
	public:
		class Iterator:public AbstractIterator {
			...
		};
};
// Then you can write code that operates over iterators:
void foreach(AbstractIterator &start, AbstractIterator &end, int (*f)(int)){
	while (start!=end) {
		f(*start);
		++start;
	}
} // This works over Lists and Sets, and any other data structure that supports Iterators

// Observer Pattern
// Publish-Subscribe model
// One class: publisher/subject - generates data
// One or more subscriber/observer classes - receive data & react to it
// Eg: publisher - spreadsheet cells
// Observer - graphs
// Can be many different kinds of observers
// Subject should not need to know all the details, otherwise makes it hard to write new observers

// Observer Pattern UML:
[	Subject				<<>>--->				[	Observer
// Code common to all subjects					// Interface commmon to all observers
+notifyObservers									+notify
+attach(Observer)
+detach(Observer)
			]											]
	^											^
	|											|
[	Concrete Subject 		<----<<>>			[	Concrete Observer
+getState										+notify
+setState(?)


			]												]	
// <<>>-> = open diamond
// May or may not have setState - that's why ? is there
			
			
// Sequence of method cals
// 1) Subject's state is updated
// 2) Subject::notifyObservers() calls each observer's notify
// 3) Each observer calls ConcreteSubject::getState to query the state and act accordingly

// Example: Horse Races
// Subject: publishes winners
// Observers: individual bettors
// Declare victory when their horse wins

class Subject {
	vector <Observer*> observers;
	public:
		bool attach(Observer *o) {observers.emplace_back(o);}
		void detach(Observer *o); // exercise
		void notifyObservers(){
			for (auto &ob:Observers)ob->notify();
		}
	virtual ~Subject() = 0;
}; // BUT class is not abstract, we need pure virtual methods - so set destructor = 0 as above.

Subject::~Subject(){} // Virtual dtor must always be implemented even if it is pure virtual
// Step 3 of dtor process - superclass dtor runs, so we must have one
// Recall:
/* Object destruction
1) dtor body
2) fields destructed
3) superclass dtor *so there had better be one
4) space deallocated
*/
// You can give pure virtual methods implementations even if it is pure virtual
// Even if you do give implementation, subclass must override it, even if it overrides it by calling superclass
// Exception from last class addressed ^

class Observer {
	public:
		virtual void notify() = 0;
		virtual ~Observer();
};

class HorseRace:public Subject {
	ifstream in; // source of data
	string lastWinner;
	public:
		HorseRace(string source):in {source}{}
		~HorseRace();
		bool runRace(); // Sets lastWinner -true if successful
		string getState() {return lastWinner;}
}