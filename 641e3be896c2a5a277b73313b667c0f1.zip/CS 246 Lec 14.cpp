// Recall
class Text:public Book {
	...
	public:
		Text(string title, string author, int numPages, string topic):
		Book{title, author, numPages} topic{topic} {}
};

// If you want to give the subclass access to certain members - use protected visibility:
class Book {
	protected:
		string title, author; // Accessible to Book and it's subclasses
		int numPages;
	public:
		...
};

class Text:public Book {
	string topic;
	public:
		...
		void addAuthor(string auth) {
			author+=auth;
		} // Not a good idea to give subclasses unlimiited access to fields
		// Having protected fields breaks encapsulation
};

// Better: private fields with protected accessors

class Book {
	string title, author;
	int numPages;
	protected:
		string getTitle() const;
		void setAuthor(string auth);
	public:
		Book(...);
		bool isItHeavy() const;
};

// Relationship among Text, Comic, Book, is called "is-a"
// a Text is a Book, a Comic is a Book
// UML
//				[Book] // protected: #
//				___^_____    
//				|		|
//			[Text]	[Comic]

// Consider isItHeavy - when is a book heavy?
/* for ordinary Books - > 200 Pages
	for Texts - > 500 Pages
	for Comics - > 30 Pages
*/

class Book {
	...
	protected:
		int numPages;
	public: 
		bool isItHeavy() const return {numPages > 200;}
};

class Comic:public Book {
	...
	public:
		...
		bool isItHeavy() const {return numPages > 30;}
};
// Text left as an exercise

Book b {"A small book", "...", 50};
Comic c {"A big comic", "...", 40, "Archie"};
cout << b.isItHeavy(); // false
	 << c.isItHeavy(); // true
// Since a comic is a Book, we can do this 
Book b = Comic {"...", "...", 40, "..."};
// Q: Is b heavy?
b.isItHeavy() // true or false
// Which isItHeavy() runs? Book::isItHeavy or Comic::isItHeavy?
// A: Not heavy. b is not heavy 
Book::isItHeavy() // runs. Why?
// In memory:
/* Book [title
		 author
		 numPages
		]
	Comic [ title
			author
			numPages
			hero
	] */
// Comic takes up more space in memory than Book does
Book b = Comic {...}; 
// Tries to fit a Comic object where there is only space for a Book object
// What happens? - Comic is sliced. (Aka the hero field is chopped off)
// Comic coerced into a Book
// So Book b = Comic {...} converts the Comic into a Book & Book:isItHeavy() runs. 
// Can't use Comic::isItHeavy() b/c what if isItHeavy utilized the hero field?
// Whether or not something is chopped off, slicing happens for consistency

// NB: methods aren't really in an object, just written like they are

// When accessing objects through pointers, slicing is unnecessary and doesn't happen
Comic c {..., ..., 40, ...};
Book *pb = &c;
Comic *pc = &c;
cout << pc->isItHeavy() // true - heavy
	 << pb->isItHeavy(); // false - not heavy still
// - still Book::isItHeavy runs.
// Same object behaves differently depending on what type of ptr points at it
// Compiler uses the type of the pointer (or reference) to decide which isItHeavy to run 
// - does not consider the actual type of the object
// Means a Comic is only a Comic when pointed at by a Comic ptr - probably not what we want

// How do we make a Comic act like a Comic, even when pointed at by a Book ptr?
// Declare the method virtual.
class Book {
	...
	public:
		Book(...);
		virtual bool isItHeavy() const {...}
};

class Comic:public Book {
	...
	public:
		bool isItHeavy() const ovverride {...}
};

Comic c {... , ... , 40 , ...};
Book *pb = &c;
Comic *pc = &c;
Book &rb = c;
cout << pc->isItHeavy() // true 
	 << pb->isItHeavy() // true (would not work if Book does not have this method)
	<< rb.isItHeavy(); // true
// When something is virtual, it is virtual forever, i.e down the class hierarchy
// In this example, it carries down to Comic.
// override forces overriding method, otherwise, if signature doesn't match even slightly, it will not override

// Comic::isItHeavy() runs in all 3 cases
// virtual method - choose which class method to run, based on the actual type of the object at runtime	
// By default, Book::isItHeavy() would run if it is not defined for a child

// Ex: my Book collection
Book *myBooks[20];
...
for (int i = 0; i < 20; ++i) {
	cout << myBooks[i]->isItHeavy() << endl;
} // isItHeavy is a virtual method, so it will use Book::isItHeavy() for Books, Comic::isItHeavy() for comics, and Text::... etc.

// Accommodates multiple types under one abstraction
// polymorphism ("many forms")

// Destructor Revisited
class X {
	int *x;
	public:
		X (int n):x{new int [n]}{}
		~X() {delete [] x;}
};

class Y: public X {
	int *y;
	public:
		Y (int m, int n): X{n}, y{new int [m]}{}
		~Y () {delete [] y;} // Cannot call delete x here b/c its private
};

X *myX = new Y{10,20};
delete myX; // This leaks memory - why?
// calls ~X but not ~Y, so only x, but not y is freed.
// How do we ensure that deletion through a superclass ptr will call the subclass dtor?
// Make the dtor virtual
class X {
	...
	public:
		...
		virtual ~x() {delete [] x;}
};

// ALWAYS make the dtor virtual in classes that are meant to have subclasses
// Even if the dtor doesn't do anything
// If a class is not meant to have subclasses, declare it final:
class Y final:public X {
	...
};
// Recall student had final field, will still compile (I didn't have to change it to finals lol)
// final and override are still valid variable names, but will mean something else at those specific locations.