// Recall the Deadly Diamond diagram in Lecture 23 and that the location of superclass is stored in the vtable

// Diagram doesn't look like all of A,B,C,D simultaneously - but slices of it look like A,B,C,D

D d;
A *a = &d; // adjusts d's address to point to the A part
// ptr asignment among A,B,C,D changes the address stored in the ptr

// static/const/dynamic casts under multi-inheritance will also change the value of the ptr
// reinterpret_cast will not

// Template functions
template <typename T> T min(T x, T y) {
	return x < y ? : x:y;
}
// Swap we used from before was a Template f'n that's why it could swap anything

int x = 1, y = 2;
int z = min(x,y); // T = int, don't need to say min <int>
// C++ can infer T = int from the types of x and y. (Note this does NOT apply to template classes)
// If C++ cannot determine T,  you can always tell it explicitly:
z = min<int>(x,y);
char w = min('a','c'); // T = char
auto f = min(1.0,3.0); // T = float

// For what types T can min be used?
// For what types T does the body compile?
// Any type for which operator < is defined (Even if you overload it yourself)

// Recall:
void for_each(AbstractIterator start, AbstractIterator finish, void (*f)(int)) {
	while (start != finish) {
		f(*start);
		++start;
	}
} // Works as long as AbstractIterator supports !=,*,++ and f can be called as a function

// Instead, make these template args:
template<typename Iter, typename Func> 
void for_each(Iter start, Iter finish, Func f) {
	while (start != finish) {
		f(*start);
		++start;
	}
} // Now Iter can be any type that supports !=,*,++ (including raw pointers, 
// which wouldn't be able to inherit from AbstractIterator b/c they're not a class)
// We can now do things like:
void f(int n) {
	cout << n << endl;
}
int a[] = {1,2,3,4,5};
for_each(a,a+5,f); // Prints the array

// STL <algorithm>
// suite of template functions, many of which work over iterators
// Example: for_each (as given above)

template <typename Iter, typename T> Iter find (Iter first, Iter last, const T&val) {
	// returns iterator to the first element in  [first, last) matching val
	// or last, if val not found
}

count // like find, but returns # of occurences of val

template <typename InIter, typename OutIter>
OutIter copy(InIter first, InIter last, OutIter result) {
	// copies one container range [first, last) to another, starting at result
} 
// Note: does not allocate new memory, so make sure you have enough (similar to strcpy)
// Ex:
vector <int> v {1,2,3,4,5,6,7};
vector <int> w (4); // space for 4 ints
copy(v.begin()+1, v.begin()+5, w.begin());
// w = {2,3,4,5}

template <typename InIter, typename OutIter, typename Func>
OutIter transform (InIter first, InIter last, OutIter result, Func f) {
	while (first != last) {
		*result = f(*first);
		++first;
		++result;
	}
	return result;
}

// Ex: 
int add1(int n) {return n+1;}
vector <int> v {2,3,5,7,11};
vector <int> w (v.size());
transform(v.begin(), v.end(), w.begin(), add1);
// w = {3,4,6,8,12};

// How general is this code?
// 1) What can we use for Func?
// 2) What can we use for InIter/OutIter?

// 1) Func - How is f used? - f(*first)
// f can be anything that can be called as a function - but f is not a function
// Can write operator() for objects
// Ex:
class plus1 {
	public:
		int operator()(int n) {return n+1;}
};
Plus1 p; 
p(4); // produces 5

transform(v.begin(), w.begin(), plus1()); // plus1() is a ctor call
// Generalize:
class Plus {
	int m;
	public:
		plus(int m): m{m} {}
		int operator() (int n) {return n+m;}
};
transform(v.begin(), v.end(), w.begin(), plus{1}); // Can take second argument in vector - currying
// plus1, plus objects - called function objects
// Advantage of objects over functions - can maintain state
class IncreasingPlus {
	int m = 0;
	public:
		int operator()(int n) {
			return n+(m++);
		}
		void reset() {m = 0;}
};

vector <int> v(5,0); // 00000
vector <int> w(v.size());
transform(v.begin(), v.end(), w.begin(), IncreasingPlus());
// w = 0,1,2,3,4

// Consider: How many ints in a vector v are even?
vector <int> v{...}
bool even(int n) {return n%2==0;}
int x = count_if(v.begin(), v.end(), even); // this is fine
// C++ has no nested function, we have to go to global/namespace scope and define the function

// Seems a waste to explicitly create the function even
// If this were Racket, we would use lambda.
// Do the same here:
int x = count_if(v.begin(), v.end(), [](int n){return n%2==0;});
// You can fit things in [], if you want your lambda to have access to local variables in scope, Ex: want to access v
// Tricky though

// What type does the lambda have? Matching Func
// It's a secret though - compiler doesn't tell us, not allowed to
// So if you want to store lambda in a variable, you have to do:
auto f = [](int n) {return n%2==0;};
void doSomething(decltype(f) g) {...} // decltype has the same type that f has

// 2) Iterators
// Apply the notion of iteration to other data sources E.g. Streams

#include <iterator>
vector <int> v {1,2,3,4,5};
ostream_iterator <int> out {cout, ","};
copy(v.begin(), v.end(), out);
// second container is now attached to cout - not a vector
// Prints 1, 2, 3, 4, 5, 
vector <int> w;
copy(v.begin(), v.end(), w.begin()); // Won't run - no space allocated for w
// Remember that copy doesn't allocate space in w
// Why? copy can't actually allocate space in w - because it doesn't know w's data structure. 
// All it has is a pointer to one element, doesn't know how much space to allocate
// Doesn't even know that w.begin() is iterating over a vector
// But what if we had an iterator whose assignment operator inserts a new item?
// If the iterator knows enough abt the class to do the insertion, then we can do:
copy(v.begin(), v.end(), back_inserter(w));
// copies v to w, allocating space if necessary
// even if copy can't allocate memory, a well constructed iterator can and will allocate space