//Ex: Echo all ints to stdout - skip non-integer input.

int main {
	int i;
	while (true) {
		if (! (cin >> i)) {
			if (cin.eof()) break;
			cin.clear(); // clear the fail bit 
			cin.ignore(); // skip a character, avoids infinite loops
		}
		else cout << i << endl;
	}
}

// When cin fails, it raises a flag, cin won't do anything as long as the flag is up
// This is why if you write a program that takes two integer inputs and put c,4 as the inputs, it will
// not read the second input. 

// Reading Strings
type std::string //(#include <string>), more details later

int main() {
	string s;
	cin >> s; // Skips leading whitespace, stops at whitespace (Reads a word)
	cout << s << endl;
}
// What if we want the whitespace? 
getline(cin, s); //reads from the current position to the next newline into s

cout << 95 << endl; // prints 95
// What if we want to print in hexadecimal?
cout << hex << 95 << endl; prints 5f // endl also flushes the buffer 
// hex is an I/O manipulator, all subsequent integers are printed in hex
// To revert back to decimal:
cout << dec;

// Other manipulators - see notes 
#include <iomanip>

// Stream abstraction
// Applies to other sources of data 
// Ex: Files - Read from a file instead of stdin
stdin::ifstream // Read from a file
stdin::ofstream // Write to a file

// File access in C:
int main{
	char s[256];
	FILE *file = fopen("myfile.txt", "r");
	while (true) {
		fscanf (file, "%255s", s);
		if (feof(file)) break;
		printf("%s\n", s);
	}
	fclose(file);
}

// File access in C++
#include <iostream>
#include <string> 
#include <fstream>
using namespace std;

int main() {
	// Initialization - Declaring the ifstream and initializing with that name opens the file
	ifstream file {"myfile.txt"}; 
	string s;
	while (file >> s) {
		cout << s << endl;
	} // File is closed automatically when the ifstream variable goes out of scope
	// To close manually, file.close();
}

// Anything you can do with cin/cout you can also do with ifstreams/ofstreams
// Example: Strings - attach a stream to a string var and read from /write to it
#include <sstream> 
std::istringstream // These read from/write to a string 
std::ostringstream

int lo, hi;
ostringstream ss;
ss << "Enter a # between " << lo << " and " << hi;
string s = ss.str();

// Another example with istringstream
int n; w
while(true){
	cout << "Enter a # " << endl;
	string s;
	cin >> s;
	istringstream ss {s}; //{s} is initialization
	if (ss >> n) break;
	cout << "I said, ";
}
cout << "You entered " << n << endl;
// The streams also raise flags, but there is a fresh stream each time to go through the loop

// Example Revisited
// Echo all #'s, skip non-#'s
int main(){
	string s;
	while (cin >> s){
		istringstream ss {s};
		int n;
		if (ss >> n) cout << n << endl;
	}
}
// Stops printing once it reads a non-integer

// Strings
// In C: array of char (char* or char[]), terminated by \0
// 		 must manage memory - allocate more memory as strings get larger
//		 easy to overwrite \0
// C++ strings: grow as needed (no need to manage memory)
// 				safer to manipulate

// C++ String
string s = "Hello"; // C-style string in memory, still an array of chars, null terminated
// Created from the C string on initialization 

// String operations in C++
// Equality 
s1 == s2, s1 != s2 // Will work, no need for strcmp
// Comparison
s1 <= s2 // Lexicographic
// Length 
s.length()
// Get individual chars:
s[0], s[1], s[2]
// Concat
s3 = s1 + s2
s3 += s4
// More details in notes

// Default function params
void printWordsInFile(string name = "suite.txt"){
	ifstream file {name};
	string s;
	while (file >> s) cout << s << endl;
}
printWordsInFile("suite2.txt");
printWordsInFile(); // suite.txt, assumes default 
// Note: Optional parameters must be last in the list of parameters

// Overloading
// C: 
int netInt(int n) {return -n;}
bool negBool(bool b) {return !b;}

// C++:
// Functions with different parameter lists can share the same name
int neg(int n) {return -n;}
bool neg(bool b) {return !b;} // Overloading
// Compiler distinguishes between the two by looking at the type and # of the arguments
// Overloads must differ in # or type of args
// May not differ just on return type
// Operators >>, <<, + are overloaded, behaviour depends on the types of args

// Structs 
// In C:
struct Node {
	int data;
	struct Node *next; // In C++, we can omit Struct
}; // Don't forget the semi-colon

// Why is this wrong:
struct Node {
	int data;
	Node next; // This is saying inside of a Node there exists an int and another node, repeats recursively infinitely
	// *next says it's a pointer that could point to the address of a Node
};

// Constants
const int maxGrade = 100; // Must be initialized
// Declare as many things const as you can

Node n1 = {5, nullptr}; // nullptr is the syntax for null pointers in C++, Don't say NULL.
const Node n2 = n1; // This is an immutable copy, can't change fields
