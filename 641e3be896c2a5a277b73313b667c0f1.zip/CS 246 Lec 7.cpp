// Overloading << and >>

struct Grade {
	int theGrade;
};

ostream &operator<< (ostream &out, const Grade &g) {
	out << g.theGrade << '%'
	return out;
}

istream &operator >> (istream &in, grade &g){
	in >> g.theGrade;
	if (g.theGrade < 0) g.theGrade = 0;
	if (g.theGrade > 100) g.theGrade = 100;
	return in;
}

// The Preprocessor
// Transforms the program before the compiler sees it
// # ______ preprocessor directives Ex: #include

// Including old C headers has a new naming convention
// Ex: Instead of #include <stdio.h>, use #include <stdio>

#define VAR VALUE // Sets a preprocessor variable
// Then all occurences of VAR in the source file are replaced by VALUE
// Ex: 
#define MAX 10;
int x[MAX]; // Transformed to int x[10];
// Use const definitions instead
#define FLAG // Sets the variable FLAG - value is the empty string

// Defined constants can be useful for conditional compilation
// Ex: 
#define IOS 1
#define BBOS 2
#define OS IOS // or BBOS
#if OS == IOS // Removed if OS != IOS
	short int publickey;
#elif OS == BBOS // Removed if OS != BBOS
	long long int publickey; 
#endif

// Special case
#if 0 // Never true - unless racket or bash lol
... // all inner text is removed before it gets to the compiler
#endif
// Heavy-duty "comment-out:" //
// C has /* ... */ but if you do something like /* ... /* ... */ ... */ it would only read it as a comment up to third /
// #if 0 would make good comments

// Can also define symbols via compiler args:
// Ex: define.cc
int main() {
	cout << x << endl;
}
// g++14 -DX=15 define.cc -o define

#define ever;;
..
for (ever){}

#ifdef NAME // true if NAME (has/has not) been defined
#ifndef NAME

int main() {
	#ifdef DEBUG
		cout << "setting x=1" << endl;
	#endif
		int x = 1;
		while (x < 10) {
			++x;
			#ifdef DEBUG
				cout << "x is now" << x << endl;
			#endif
		}
		cout << x << endl;
}
// g++14 -DDEBUG debug.cc -o debug
// Enables debug output

// Defining something on cmd line without a value yields 1

// Separate Compilation
// Split programs into composable modules, with 
// interface - type def'ns, function prototypes - .h file
// implementation - full def'n for every provided f'n - .cc file
// Recall: DEclaration - asserts existence
// definition - full details - allocates space (vars and functions)

//Ex:
// interface vec.h
struct vec {
	int x,y;
}
vec operator + (const vec &v1, const vec &v2);
...

// Client main.cc
#include "vec.h"
int main() {
	vec v {1,2};
	v = v+v;
}

// Implementation vec.cc
#include "vec.h" // For compiler to know what a vec is, declared in the interface
vec operator + (const vec &v1, const vec &v2){
	... // Full def'n
}
// Recall: An entity can be declared any # of times, but defined only once

// Compiling Separately
/* g++14 -c vec.cc 
   g++14 -c main.cc
   g++14 vec.o main.o -o main
   // Links object files into an executable
*/
// -c = compile only - do not link - do not build an executable
// - Produces an object file (.o)
// NEVER compile .h files

int globalNum; // Where do you put it?
// Putting it into .h will work - until you start using it
// Everytime the header is used, it will create a new global variable with the same name, linker error
// Can fix by:
extern int globalNum; // in .h
// and
int globalNum; // in .cc
// structs don't exist at runtime, so linker has nothing to do with them and so extern is not needed

// Lets write a linear algebra omdule
// linalg.h
#include "vec.h"
...
// linalg.cc
#include "linalg.h"
#include "vec.h"
...
// main.cc
#include "linalg.h"
#include "vec.h"
// Won't compile because main.cc and linalg.cc include linalg.h and vec.h
// linalg.h includes vec.h, implying that vec.h is included twice and implies that two definitions of the struct vec
// and that's not allowed 

// Need to prevent file from being included more than once
// Sol'n: "#include guard"
// vec.h
#ifndef VEC_H
#define VEC_H
...
//File Contents
...
#endif
// First time vec.h is included, VEC_H is not defined, so the file is included.
// After that, VEC_H is defined, so contents of vec.h are suppressed
// Always put #include guards in .h files
// Never: include .cc files
