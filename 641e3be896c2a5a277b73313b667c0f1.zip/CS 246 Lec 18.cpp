// Cont'd from last lecture:
// Now consider:
Text t1 {...}, t2 {...};
Book *pb1 = &t1, *pb2 = &t2;
// What if we do: 
*pb1 = *pb2;
// Partial assignment - copies only the Book part
// Because Book::operator= runs
// How can we fix this? Try making operator= virtual
class Book {
	...
	public:
		virtual Book &operator=(const Book &other);
};

class Text: public Book {
	...
	public:
		Text &operator=(const Text &other) override; // Not overriding anything b/c parameters are different, two different methods
		// To fix, change to (const Book &other)
		// Don't have to change the return type
};

// Note: different return types are OK as long as you return a subclass by reference/pointer
// But, parameter types must be the same or it's not an override, won't compile and violates is-a (Ex: text is-a book)
// Therefore, Assignment of a Book object to a Text var would be allowed:
Text t {...};
Book b {...};
Text *pt=&t;
Book *pb=&b;
*pt=*pb; // This is allowed, using a Book to assign a Text even though Book doesn't have a topic field, but still allowed
// It's bad, but it'll compile
// Also
Comic c {....}
Comic *pc = &c;
*pt = *pc; // This works too, really bad
// If operator= not virtual - partial asignment through be class ptrs
// If virtual - compiler allows mixed assignment

// non virtual operator= problem isn't with slicing - but only transferring some of the fields, it's partial assignment, NOT slicing

// Recommendation: All superclasses should be abstract
// Rewrite Book hierarchy

/* [abstractBook]
		^
	Inherits
		|
	_____________________
	|			|		|
[NormalBook]	[Text]	[Comic]
*/

class AbstractBook {
	string title, author;
	int numPages;
	protected:
		AbstractBook &operator= (const AbstractBook &other);
	public:
		AbstractBook(...);
		virtual ~AbstractBook()=0; // Make it pure virtual if no other methods are
};

class NormalBook: public AbstractBook {
		public:
			NormalBook(...);
			~NormalBook();
			NormalBook &operator= (const NormalBook &other) {
				AbstractBook::operator=(other);
				return *this;
			}
}; // Other classes - exercise

Text t1 {...}, t2{...};
AbstractBook *pa1=&t1, *pa2=&t2;
*pa1=*pa2; // Doesn't compile - b/c protected, subclasses can use it but not outsiders
// Prevents assignment through base class pointers from compiling, but implementation still available to subclasses

// Factory Method Pattern
// Write a video game with 2 kinds of enemies - turtles and bullets
// System randomly sens turtles and bullets, but bullets become more frequent closer to the end
// UML:
/*
		[Enemy]							[Level]
			^								^
		Inherits						Inherits
			|								|
			|								|
		_________						________________
		|		|						|				|
	[Turtle]	[Bullet]			[Normal Level]	[Castle]
*/

// Never know exactly which enemy comes next, so can't call ctors directly
// Put a factory method inside level that creates enemies

class Level {
	public:
		virtual Enemy *createEnemy()=0;
};

class NormalLevel: public Level {
	public:
		Enemy *createEnemy() override {
			// create mostly turtles
		}
};

class Castle: public Level {
	public:
		Enemy *createEnemy() override {
			// creates mostly bullets
		}
};

Level *l = new NormalLevel;
Enemy *e = l->createEnemy();

// Template Method Pattern
// Want subclasses to override superclass behaviour but some aspects must stay the same
// Ex: There are red turtles and green turtles
class Turtle {
	public:
		void draw() {
			drawHead();
			drawShell();
			drawTail();
		}
	private:
		void drawHead();
		void drawFeet();
		virtual void drawShell() = 0;
};

class RedTurtle: public Turtle {
	void drawShell() {
		// draw red shell
	}
};

class GreenTurtle: public Turtle {
	drawShell() {
		// draw green shell
	}
};

// Subclasses can't change the way a turtle is drawn (i.e. head, then shell, then feet), but can change the way the shell is drawn
// void draw(){...} is known as the template method
// Extension: the Non-Virtual Interface (NVI) idiom
// A public virtual method is really two things, 
// an interface to the client - indicates provided behaviour with pre/post conditions
// an interface to subclasses - a "hook" to insert specialized behaviour
// Hard to separate these ideas if they are tied to the same function

// What if you want to separate the customisable behaviour into two functions, with some unchanging code in between, 
// while still providing clients the same interface?
// How could you make sure that overriding functions confirms to pre/post conditions?

/* NVI Says:
- all public methods should be non-virtual
- all virtual methods should be private, or at least protected
- except the dtor
*/

// Example:
class DigitalMedia {
	public:
		virtual void play() = 0;
};
// Changed to:
class DigitalMedia {
	public:
		void play() {
			doPlay();
		}
	private:
		virtual void doPlay() = 0;
};
// What if you want to control when something plays (Ex: if media is copyrighted):
class DigitalMedia {
	public:
		void play() { // can add before/after code
			// Check copyright
			doPlay();
			//update playCount
		}
	private:
		virtual void doPlay() = 0;
};

// Extends template method - EVERY virtual method is inside a template method

// STL Maps - for creating Dictionaries
// Ex: "arrays" that map strings to ints
#include <map>
map <string,int> m;
m["abc"] = 1;
m["def"] = 2;
cout << m["ghi"]; // if key not present, it is inserted, and value is default-constructed (for ints, 0)
cout << m["abc"]; // 1
m.erase("abc");

if (m.count("def"))... // Ask the map how many times a key occurs 1=found, 0=not found
// multimap in STL CAN have more than one key, but not map, so might as well use it here too
// Iterating over a map: sorted key order

for (auto &p:m) {
	cout << p.first << ' ' << p.second << endl;
}
// p's type is 
std::pair<string,int> & (<utility>)
// pairs are structs, p.first are field accessors not method calls