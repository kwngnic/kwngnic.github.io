// Exception safety & the STL continued

vector<T>::emplace_back // provides the strong guarantee
// If the array is full (i.e. size = cap):
// allocate a new array
// - If you throw when allocating, nothing happens, still have old array
// copy objs over (copy ctor) 
// - if a copy ctor throws, destroy the new array, old array still intact, strong guarantee
// delete old array
// - delete never throws

// BUT - copying is expensive, and the old data will be thrown away
/* Wouldn't moving the objs be more efficient?
allocate new array
move the objs over (move ctor) 
delete old array */
// If the move ctor throws, can't offer the strong guarantee, because the original is no longer intact
// If the move ctor offers the no-throw guarantee, emplace_back 
// will use the move ctor; else it will use the copy ctor which will be slower
// So your move ops should provide the no-throw guarantee, and you should indicate that they do

class MyClass {
	public:
		MyClass (MyClass &&other) noexcept {...}
		MyClass &operator= (MyClass &&other) noexcept;
};
// If you know a function will never throw or propagate an exception, declare it no no except - facilitates optimization
// noexcept comes before MIL

// At minimum: swaps & moves should be noexcept 
// (the move ctors written prior were all noexcept, just assigning pointers to NULL or to other ptrs)

// Casting
// In C:
Node n;
int *ip = (int *)(&n); // (&n) is cast
// forces C++ to treat a Node * as an int *
// C-style casts should be avoided in C++. If you must cast, use a C++ - style cast
// 4 kinds:

// - static_cast - "sensible" casts
// Eg: double -> int
double d;
void f (int i);
void f (double d);
f (static_cast<int>(d)); // Treats d as an int, calling the first version of f

// superclass ptr to subclass ptr
// superclass pointing to subclass is fine without doing anything but not the other way around
Book *b = new Text {...};
Text *t = static_cast<Text *>(b);
// You are taking responsibility that b actually points at a Text "Trust me"

// reinterpret_cast
// unsafe, implementation-specific, "Weird" casts
Student s;
Turtle *t = reinterpret_cast<Turtle *>(&s);

// const_cast
// for converting between const and non-const
// the only C++ cast that can "cast away const"
// Can't change a const to a variable, b/c const is still in read-only memory so trying to reassign it will crash

void g (int *p); // Given to you
void f (const int *p) {
	...
	g(p);
	...
} // Suppose you know that g doesn't actually modify *p, just not indicated in the header, then do:
void f (const int *p) {
	...
	g(const_cast<int *>(p));
	...
}
// Otherwise, you'd get a type error

// What if you had a program that did this:
/*				Program
		[Uses const][Doesn't use const]
Error in one when fixed may cause errors in other, etc, etc.
*/ 

// dynamic-cast
// Is it safe to convert a Book * to a Text *?
Book *pb;
...
static_cast<Text *>(pb)->getTopic(); // Safe?
// Depends on what pb actually points at
// Better to do a tentative cast - try it and see if it succeeds
Book *pb = ...;
Text *pt = dynamic_cast<Text *>(pb);

// If the cast works (pb really points at a Text, or a subclass of Text), pt points at the object
// If the cast fails, pt will be a nullptr
if (pt) cout << pt->getTopic();
else cout << "Not a Text";

/// Should be using smart ptrs - can we do this? Yes
static_pointer_cast
const_pointer_cast
dynamic_pointer_cast // These cast shared_ptrs to shared_ptrs
// There is no reinterpret_pointer_cast
// Can use dynamic casting to make decisions based on an objects RTTI (run-time type information)
void what IsIt(shared_ptr<Book> b) {
	if (dynamic_pointer_cast<Comic>(b)) {
		cout << "Comic";
	} else if (dynamic_pointer_cast<Text>(b)) {
		cout << "Text";
	} else cout << "Normal Book";
} // Highly coupled with Book hierarchy, not good, may indicate bad design
// Better: - use virtual methods, or write a visitor

// Dynamic casting also works with references:
Text t{...};
Book &b = t;
Text &t2 = dynamic_cast<Text &>(b);
// If b "points to" a Text, t2 is a ref to the same Text
// If not...? (There's no such thing as a null reference)
// Raises exception bad_cast

// Note: dynamic casting only works on classes that have at least one virtual method
// usually done w/ inheritance, should have a virt. desturctor.