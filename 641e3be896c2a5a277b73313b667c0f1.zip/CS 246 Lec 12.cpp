// CS 246 Lec 12

// Continued from last lecture 
// Lol i just fucking copied last class' shit
class List {
	struct Node;
	Node *theList = nullptr;
	public:
		void addToFront(int n);
		int ith(int i) const;
		~List();
};

// list.cc
#include "list.h"
struct List::Node {
	int data;
	Node *next;
	Node(___):___{}
	~Node {delete next;}
};
void List::addToFront(int n) {
	theList = new Node{n, theList};
}

int List::ith(int i) const {
	Node *cur = theList;
	for (int n = 0; n < c && curr; ++n, cur = cur->next);
	return cur->data;
}
List::~List(){delete theList;}

// Only List can create/manipulate Node objects
// Therefore, can guarantee the invariant that next is always nullptr or allocated by new

// BUT - Now we can't traverse the list from node to node as we would a linked list
// Repeatedly calling ith to access the whole list - O(n^2) time
// But we can't expose the nodes or we lose encapsulation

// SE Topic: Design Patterns
// Certain problems arise frequently and have well-studied solutions
// Keep track of these and use in similar situations

// Design Pattern - If you have problem X, technique Y may solve it
// Sol'n: Iterator Pattern
// Create a class that manges access to nodes
// Abstraction of a ptr
// Walk the list without exposing the actual ptrs

for (int *p = a; p!= a+n; ++p) {
	*p...
}

class List {
	struct Node;
	Node *theList = nullptr;
	public:
		class Iterator {
			Node *p;
			public:
				// nesting Iterator gives it access to Node
				// Also can have multiple "iterator" classes inside multiple classes w/ same name
				explicit Iterator(Node *p):p{p}{}
				// Taking smth by reference suppresses copying
				// Gets the actual field itself, can change what's in the list
				int &operator*(){return p->data;}
				Iterator &operator++(){
					p=p->next;
					return *this;
				}
				bool operator==(const Iterator &other) {
					return p==other.p
				}
				bool operator!=(const Iterator &other){return !(*this==other);}
		}; // Iterator
				Iterator begin() {return Iterator {theList};}
				Iterator end() {return Iterator {nullptr};}
				...
};

// Client
int main() {
	List l;
	l.addToFront(1);
	l.addToFront(2);
	l.addToFront(3);
	// Runs in linear time
	for (List::Iterator it=l.begin(); it != l.end(); ++it) {
		cout << *it << endl;
	}
}

// Shortcut: Automatic type deduction
auto x = y; // automatically gives x the same type as y;
// Saves characters lol
for (auto it = l.begin(); it!=l.end(); ++it) {
	cout << *it << endl;
}
// Shorter cut - range-based for loop
// n is the type of items in the list - it is a copy of the items in the list
for (auto n:l) {
	cout << n << endl;
}

// If you want to modify the list elements (or save copying) 
for (auto &n:l){
	++n;
}

// auto is available for any class with
// methods begin + end that produce iterators
// the iterator must support !=, prefix++, unary*
// Will return later

// Encapsulation contd
// List client can create iterators directly:
auto it = List::Iterator{nullptr};
// violates encapsulation - Client should be using begin/end
/* We could - make Iterator's ctor private
   then client can't call List::Iterator
   but then neither can List
   Sol'n - give List privileged access to Iterator - make it a friend
*/

class List {
	...
	public:
		class Iterator {
			Node *p;
			explicit Iterator (Node *p);
			public:
			...
				friend class List; // List has access to all members of Iterator
		};
		...
};
// Now, List can still create iterators, but client can only create iterators via begin/end
// Advice - Give your class as few friends as possible - weakens encapsulation
// If changes are made in the class, will probably also have to change it for all friends

// Again: Keep fields private
// If you want the client access to fields - use accessor & mutator methods instead
class Vec {
	int x,y;
	public:
		int getX() const {return x;} // accessor method
		void setY(int newY) {y = newY;} // mutator method, want to maintain invariance
};

// What about operator <<?
// needs x&y, but can't be a member
// if no getX, getY defined - make operator << a friend function 
class Vec {
	...
	public:
	...
		friend std::ostream&operator<<(std::ostream &out, const Vec &v);
		// Declaring external operator as a friend
};

// .cc
ostream &operator<< (ostream&out, const Vec &v) {
	return out << v.x << ' ' << v.y;
}

// Tools topic: make
/* Separate compilation: 
g++14 -c list.cc
g++14 -c node.cc
g++14 -c iter.cc
g++14 -c main.cc
g++14 list.o node.o iter.o main.o -o myprog
*/

// Why do we do this? So we don't recompile the files that haven't changed
// How do you keep track of what's changed & what hasn'table
// Let Linux help - with make
// Create a Makefile that says which files depend on which other files
myprog:main.o list.o node.o iter.o // myprog depends on these
	g++-5 main.o list.o node.o iter.o -o myprog // How to build myprog from these
^ // this space must be a tab character 
list.o:list.cc list.h node.h
	g++-5 -std=c++14 -c list.cc
node.o:node.cc node.h list.h
	g++-5 -std=c++14 -c node.cc
//etc
// Then, from the command line:
make 
// Now just change iter.cc
make
// compiles iter.cc, relinks main