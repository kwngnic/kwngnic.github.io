struct Node {
	int data;
	Node *node;
	Node (int data, Node *next): data {data}, next{next}{}
	...
};

Node *n = new Node {1, new Node {2, new Node {3, nullptr}}};
Node m = *n;
Node *p = new Node {*n};

// Stack  Heap
n[-]---->[1][-]>[2][-]>[3][\]
m[1][-]----------^
p[-]-->[1][-]------^

// Simple copy of fields => Shallow Copy
// If you want a deep copy, you must write your own copy ctor

struct Node {
	...
	Node (const Node &other):
		data {other.data}
		next{other.next? new Node{*other.next}:nullptr}
		{}				 // ^ Calls copy ctor, recursively copies the whole list
};

/* The copy ctor is called:
1) When an object initializes another object
2) When an object is passed by value*   
2.5) Copy ctor can't pass by value or else you will be calling the copy constructor before calling the copy constructor - infinte recursion
3) When an object is returned by value*
* - Exceptions to be covered later
*/

// Uniform Initialization
int x = s;
int x(5);
string s = "Hello";
string s("Hello");
Student billy (60,70,80);
// For the most part, brace bracket initializers can be used everywhere,
// except stuff like default function parameters
int x{5};
string s{5};
Student billy {60,70,80}
// Careful - with ctors that can take one argument
struct Node {
	...
	Node(int data):data{data}, next{nullptr}{}
	...
};

// Single -arg ctor create implicit conversions
// Ex:
Node n{4};
// but also
Node n = 4; // Implicit conversion from int to Node

int f (Node n) {...}
f(4); // Works - 4 implicitly converted to Node, but most ints AREN'T nodes

// The danger is accidently passing an int to a function taking a Node
// Compiler will not signal an err
// Good idea - disable the implicit conversion, make the ctor explicit

struct Node {
	...
	explicit Node (int data): data{data}, next{nullptr}
		{}
};
Node n{4}; // OK
Node n = 4; // Error
// If you have > 1 argument, but the other ones are optional, still throw on explicit, it CAN still take 1 argument

// Destructors
// When an object is destroyed
// stack-allocated: goes out of scope, heap-allocated: is deleted
// a method called the destructor (dtor) runs
/* 
1) dtor body runs
2) fields' dtors are run in reverse decl'n order
3) space is deallocated
*/
// Classes come with a dtor (empty body - just does step 2)
// When do we need to write one?
Node *np = new Node {1, new Node {2, new Node {3, nullptr}}};
// If np goes out of scope - the pointer is reclaimed b/c it was stack allocated
// ... and the entire list is leaked
// If we say delete np; called *np's dtor
np[-]>[1][-]>[2][-]>[3][\]
// Built in dtor doesn't do anything, fields are not objects [2] onwards is leaked
// Write a dtor to ensure the entire list is freed

struct Node {
	...
	~Node() {
		delete next; // Recursively calls *next's destructor and frees the whole list
	}
};
// Now, delete np; frees the whole list

// Copy Assignment Operator
Student billy {60,70,80};
Student jane = billy; // copy ctor
Student anne; // default ctor
anne = billy; // Not a ctor, object already exists, but it IS a copy
// This is a copy assignment operator - uses compiler-supplied default
// May need to write your own
struct Node {
	...
	// Node &... is so that cascading works
	// = in C is an expression, not just assignment, so you can do a=b=c=4}
	Node &operator = (const Node &other){
	data = other.data;
	delete next; // Stops leak
	next = other.next? new Node {*other.next} : nullptr;
	return *this;
	}
} // This is dangerous
// Why? Node n {1, new Node {2, new Node {3, nullptr}}}
n = n; // Own nodes are deleted (n), then attempting to copy n to n
// Undefined behaviour
*p = *q
a[i] = a[j] // These fuck it up too
// When writing operator=, ALWAYS be wary of self-assignment 
struct Node {
	...
	&operator=(const Node &other) {
		if (this == &other) return *this;
		data = other.data;
		delete next;
		next = other.next? new Node {*other.next}:nullptr; // If new fails, next points to old data, undefined, list is corrupted
		return *this;
	}
};

// Better:
Node &operator(const Node &other){
	if (this == &other) return *this;
	Node *tmp = next;
	next = other.next ? new Node {*other.next}:nullptr; 
	data = other.data;
	delete tmp;
	return *this;
} // if new fails, the assignment fails but the original list is still intact, Node is still in a valid state
// Self assignment check not needed, it'd just copy itself, but probably good to keep it in for efficiency
// so you don't have to copy itself when not needed

// Alternative: Copy and swap idiom
#include <utility>
struct Node {
	...
	void swap(Node &other) {
		using std::swap;
		swap(data, other, data);
		swap(next, other, next);
	}
	Node &operator = (const Node &other) {
		Node tmp = other; // tmp is a copy of other
		swap(tmp); // me, this - copy of other tmp, my old data
		return *this; // tmp is stack-allocated, destroyed in return, reclaims my old data
	}
};