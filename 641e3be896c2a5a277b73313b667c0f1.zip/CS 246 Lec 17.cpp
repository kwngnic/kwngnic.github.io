// Refer to Subject/Observer diagram in Lec 16
// Similar Code to last class
class Observer {
	virtual void notify()=0;
	virtual ~Observer(){}
};

class Subject {
	vector <Observer *> observers;
	public:
		void attach (Observer *o);
		void detach (Observer *o);
		void notifyObservers();
		virtual ~Subject()=0;
};
Subject::~Subject(){}

class Bettor: public Observer {
	HorseRace *subject;
	string name, myHorse;
	public:
		Bettor(...):... {
			subject->attach(this);
		}
		~Bettor() {
			subject->detach(this); // Don't need to delete pointer HorseRace, observer doesn't own the race
		}
		void notify() override {
			string winner = subject->getState();
			if (winner == myHorse) {
				cout << "Yay";
			} else {
				cout << "Double or nothing";
			}
		}
};

int main() {
	HorseRace hr{...};
	Bettor Larry(&hr, "Larry", "RunsLikeACow");
	...
	while (hr.runRace()) {
		hr.notifyObservers();
	}
}

// Decorator Pattern
// Want to enhance an object at run-time
// - Add functionality/features

/* Ex: Windowing system 
- start with a basic window
- add a scrollbar
- add a menu
*/
// Want to choose these enhancements at run-time

// Decorator Pattern:
// Took photo fuck this lol
// Remember he uses cursive for abstract classes

// Class component: defines the interface - operations your objects will provide
// Concrete Component - implements the interface
// Decorators - all inherit from Decorator, which inherits from Component
// Therefore, every Decorator is a Component and every Decorator has a Component

// Ex: Window with scrollbar is a kind of window, and has a ptr to the underlying plain window
// Window w/ scrollbar and menu is a window, has a ptr to a window w/ scrollbar, which has a ptr to a plain window
// All inherit from Abstract Window class, so Window methods can be used polymorphically on all of them

// Ex: 
/* [Pizza] <----------------------------------
	  ^ // Triangle							 |
	  |_____________________				 |
	__| 					|_				 |
	|						  |				 |
	[Crust and Sauce]		[Decorator]<<>>--|
	[				]			|
						________|________
						|		|		|
					[Topping][Stuffed  [Dipping Sauce]
								Crust]
*/
// Basic Pizza is crust and sauce
class Pizza {
	public:
		virtual float price() const = 0;
		virtual string desc() const = 0;
		virtual ~Pizza();
};
class crustAndSauce:public Pizza {
	public:
		float price() const override {return 5.99;}
		string desc() const override {return "Pizza";}
};

class Decorator:public Pizza {
	protected:
		Pizza *component; // Represents the <<>> arrow
	public:
		Decorator(Pizza *p): component{p} {}
		virtual ~Decorator() {delete component;} // Observer "has a" Pizza, but we're attempting to delete component anyways
		// The question comes down to whether or not you can pick toppings off a pizza (Yes or no?)
		// If your pizza has multiple toppings, cannot pick off the bottom one without picking the top ones off then reconstructing
		// Not ideal
};

class Topping:public Decorator {
	string theTopping;
	public:
		Topping(Pizza *p, string topping): Decorator{p}, theTopping{topping}{}
		float price() const override {
			return component->price() + .75;
		}
		string desc () const override {
			return component->desc() + "with" + theTopping;
		}
};

// Use:
Pizza *p1 = new CrustAndSauce;
p1 = new Topping(p1, "Cheese");
p1 = new Topping(p1, "Jelly Beans");
p1 = new StuffedCrust(p1);
cout << p1->desc() << " " << p1->price();
delete p1;

// Inheritance and Copy/Move
class Book {
	// Defines copy/move ctors, copy/move assign
};

class Text:public Book {
	// Does not define copy/move operations
};

Text t {"Algorithms", "CLRS", 500, "CS"};
Text t2 = t; // No copy ctor in text - what happens?
// calls Book's copy ctor, then goes field-by-field (i.e default behaviour) for the Text part
// Same for other operations

// To write your own operations:
Text::Text(const Text &other): Book{other}, topic{other.topic}{}
Text &Text::operator=(const Text &other){ // No MIL
	Book::operator=(other);
	topic=other.topic;
	return *this;
}

Text::Text(Text &&other):{ // This is WRONG
	Book{other}, topic{other.topic}
} {}// This is WRONG

Text::Text(Text &&other):{ // This is still WRONG
	Book{std::move (other)}, topic{other.topic}
} {}// This is still WRONG
// other and other.topic are both lvalues - would get copied & is inefficient

Text::Text(Text &&other):{
	Book{std::move other}, topic{std::move other.topic}
} {}

Text &Text::operator=(Text &&other) {
	Book::operator=(other); //must change other to std::move(other) or else you're doing copy-move assn
	topic=other.topic; // same here, std::move(other.topic)
	return *this
}

// Note: Even though other "points" at an rvalue, other itself is an lvalue, along with other.topic.
// std::move(x) forces an lvalue x to be treated as an rvalue, so that the "move"versions of the operators run
// Operations given above are equivalent to the compiler-supplied defaults

// Now consider:
Text t1 {...}, t2 {...};
Book *pb1 = &t1, *pb2 = &t2;
// What if we do: 
*pb1 = *pb2;