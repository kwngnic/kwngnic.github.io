// CS 246 Lecture 6

Recall: void inc (int n) {++n;}
...
int x = 5;
inc(x)
cout<<x<<endl; // Prints 5

// Pass by Value - inc gets a copy of x, increments the copy - original is unchanged

// If a function needs to modify an argument - pass a ptr_fun

void inc (int *n) {++*n;}
...
int x = 5 
inc(&x); // x's address passed by value, changes to the pointed-at data (i.e. x) visible.
cout << x << endl; // 6

// Q: Why cin >> x and not cin >> &x
// A: C++ has another ptr-like type: references

int y = 10;
int &z = y; // z is an lvalue reference to int
// Like a const. ptr
// Similar to int *const z = &y;
// References are like constant ptrs with automatic dereferencing
// Ex:
// y -> 10
// z points to value of y, won't change where it points
// If you then do 
z = 12; // NOT *z = 12
// Now, y == 12.
int *p = &z; // This gives the address of y
// In all cases, z behaves EXACTLY like y
// z is an alias ("Another name") for y

// Things you can't do with lvalue references 
// 1) Leave them uninitialized, Ex:
int &x;
// Must be initialized with something that has an address (an lvalue) since refs are ptrs
int &x = 3; // Would be wrong, three does not sit in memory anywhere
int &x = y+z; // Also wrong, not sitting in memory
int &x = y; // This, you can do

// 2) Create a ptr to a reference:
int &*x; // Can't do this - x is a pointer to the address of an int
// ref to ptr OK: 
int *&x = ... ;

// 3) Create a reference to a reference
int &&x; // Will work, but this means something different (Later)

// 4) Create an array of references:
int &r[3] = {n,n,n}; // Can't

// What CAN you do? 
// Pass as function parameters

void inc (int &n) {++n;} // No ptr deref. &n is a const ptr to the arg(x)
int x=5; 
inc(x);
cout << x << endl; // 6
// Why does cin >> x work? Takes x by reference

istream &operator >> (istream &in, int &data)
// Can't copy streams

// Pass-by-value, Ex:
int f(int n) {...} // Copies the arg
// If the arg is big, copying the argument is expensive
// Eg: 
Struct ReallyBig {...}
void f(ReallyBig rb) {...} // Copying is slow
void g(ReallyBig &rb) {...} // Alias, fast - But could change rb in the caller

int h (const ReallyBig &rb){...} // Fast, no copying, params cannot be changed
// Advice: Prefer pass-by-const-ref over pass-by-value for anything larger than a ptr,
// Unless the function needs to make a copy anyways, then maybe use pass-by-values
// Also: 
int f(int &n){...}
int g(const int &n) {...}
f(5); // This will not compile, can't initialize an lvalue reference (n) to a literal value
// if n changes, can't change the literal 5
g(5); // This is legal - since n can never be changed, the compiler allows this
// How? Compiler creates a temporary location to hold the 5, so that n has something to point at

// Dynamic Memory Allocation
// C:
int *p = malloc (_____* sizeof(int));
...
free(p); // Don't use these in C++
// Instead:
new/delete // type-aware, less error-prone
// Ex:
struct Node {
	int data;
	Node *next;
};

Node *np = new Node;
...
delete np;
// np is on the stack, data and next are on the heap
// All local vars reside on the stack - vars are deallocated when they go out of scope (Stack is popped)
// Allocated memory resides on the heap and remains allocated until delete is called
// If you don't delete all allocated memory -> memory leak, program will eventually fail, incorrect
Node *np = new Node[10]; // 10 nodes
...
delete [] np;

// Eg:
Node getMeANode() {
	Node n;
	return n;
} // Return by value = copy - expensive(?)
// Return a ptr (or ref) instead?

Node *getMeANode() {
	Node n;
	return &n;
} // Bad - returns a ptr to stack-allocated data, which is dead on return

Node *getMeANode() {
	return new Node; // OK - returns a ptr to heap data - still alive, but don't forget to delete
}

// Operator Overloading
// Give meanings to C++ operators for our own types
// Eg:
struct Vec {
	int x,y;
};

Vec operator+(const Vec &v1, const Vec &v2) {
	Vec v = {v1.x+v2.x, v1.y+v2.y};
	return v;
}

Vec operator * (const int k, const vec &v) {
	return {k * v.x, k * v.y} // Didn't use word Vec, but compiler knows that the function is supposed to return type Vec, based on return type
} // Only supports stuff like 2*v, not v*2
Vec operator * (const vec &v, const int k) { // Other way around
	return k * v;
}

// Overloading << and >>
// Ex:
struct Grade {
	int theGrade;
};

ostream &operator << (ostream &out, const Grade &g) {
	out << g.theGrade << '%'; // Leave out endl, can always add later
	return out;
}