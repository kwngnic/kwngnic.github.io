// Command make - builds the first target (myprogram) in the Makefile
// What does myprogram depend on? -> the .o files
// Recursively builds those, if necessary
// Rebuild myprogram, if necessary
// iter.cc changes - now newer than iter.o, therefore rebuild iter.o
// iter.o is now newer than myprogram, therefore rebuild my program
// Can also build specific targets, e.g. make node.o

// Common: a target clean: - removes all binaries
// Useful if you want a full rebuild or if you want to get rid of all binaries and just archive the source
/*
Normal stuff here
*/
.PHONY: clean

clean:
	rm *.o myprogram
	
// To do a full rebuild: 
make clean
make

// Generalize with variables
CXX = g++-5 // (compiler's name)
CXXFLAGS = -std=c++14 -Wall // Wall turns on warnings
// Ex: 
iter.o: iter.cc list.h
	${CXX} ${CXXFLAGS} -c iter.cc
// Shortcut: for any rue of the form:
x.o: x.cc a.h bh ...
// Can leave out the build command
// Make will guess that you want 
${CXX} ${CXXFLAGS} -c x.cc -o x.o
// Hardest part of writing Makefiles
/* - Dependencies
- and maintaining them if they changes
*/

// Can get help from g++:
g++-5 -std=c++14 -MMD -c iter.cc
// This creates iter.o and iter.d
// iter.d looks like:
iter.o: iter.cc list.h node.h
// Now just include these into the Makefile
...
CXXFLAGS= -std=c++14 -Wall -MMD
OBJECTS= main.o list.o iter.o node.o
DEPEND= ${OBJECTS:.o=.d} // replace .o with .d
...
-include ${DEPENDS}

// System Modelling
// Building an OO system - 
/* identify abstractions
   formalize relationships among them
*/
// Helpful to map these out
// Popular Standard: UML (Unified Modelling Language)
// Modelling a class
Name 					[Vec]
Fields(optional)		[-x: Integer
						 -y: Integer]
Methods(optional)		[+getX: Integer
						 +getY: Integer]
Visibility: - means private, + means public
// Note the use of Integer and not int

// Relationship: Composition of Classes
class Vec {
	int x,y;
	public:
		Vec(int x, int y);
};
// Two Vecs define a Basis:
class Basis {
	Vec v1, v2;
};

Basis b; // Does not compile - basis uses built-in default constructor, which says default construct all fields that are objects,
// which v1 and v2 are BUT Vec doesn't have a default constructor, so this doesn't compile 
// Can't initialize v1, v2

// Solution
class Basis {
	Vec v1, v2;
	public:
		Basis (): v1 {1,0}, v2{0,1} {} // Use values of 0 and 1 to construct v1, v2 when Basis' default constructor is called
};

// Embedding one obj(Vec) inside another (Basis) is called composition
// Relationship between Basis & Vec called "owns-a"
// A Basis "owns" two Vec objects

// If A "owns a" B, then typically: 
/* B has no identity outside A (B is a part of A)
   If A is destroyed, B is destroyed
   If A is copied, B is copied (deep copies)
*/

// Ex: A car owns 4 wheels - a wheel is part of a car
// Destroy the car => destroy the wheels
// Copy the car => Copy the wheels

// Implementation: Usually as composition of classes
// Modelling:
		// v1v2
[Basis]<<>>---->[Vec]
			2
// Or, basis owns two Vecs

A <<>>---> B // means A owns some # of B
// More details: links on course website

// Aggregation
// Compare car parts in a car ("owns a")
// vs. car parts in a catalogue
// The catalogue contains parts, but the parts have an independent existence
// This is a "has a" relationship (Aggregation)

// If A "has a" B, then typically:
// B has an existence apart from its association with A
// If A is destroyed, B lives on
// If A is copied, B is not (implies shallow copies), copies of A share the same B
// Ex: ducks in a pond
// UML: 
[Pond]<>---->[Duck]
		0..*
		
		
// Typical Implementation: pointer fields
// By no means mandatory
class Pond {
	Dark *ducks[maxDucks];
};

// Specialization/Generalization (Inheritance)
// Suppose you want to track your collection of books

class Book {
	string title, author;
	int numPages;
};

class Text {
	string title, author;
	int numPages;
	string topic;
};

class Comic {
	string title, author;
	int numPages;
	string hero;
};
// Does not capture the relationship among these classes
// How would you create an array or a list that contains a mixture of these?
// No need to retrieve smth as a Book only, or a void *
// In C++ - use inheritance

class Book { // Base class or super class
	string title, author;
	int numPages;
	public:
		Book(...);
};

class Text: public Book { // Derived Class or Subclasses
	string topic;
	public:
		Text(...);
};
class Comic: public Book { // Derived Class or Subclasses
	string hero;
	public:
		Comic(...);
};

// Derived classes inherit fields & methods from the base class
// Therefore, Text and Comic get title, author, numPages fields.
// Any method that can be called on Book can be called on Text and Comic
// Recall ifstreams can do anything istreams can do, b/c they inherit from them

// Who can see those members?
// title, etc. are private in Book - outsiders can't see them
// Can Text and Comic see them? Nope - even subclasses can't see them

// How do we initialize Text?
class Text: public Book {
	...
	public:
		Text(string title, string author, int numPages, string topic): title{title}, author{author},
		numPages{numPages}, topic{topic} {} // Doesn't work lmao
};
// Wrong for 2 reasons:
// 1) Title, etc. not settable in Text's MIL (Not your fields, and also you can't access them anyways)
// 2) When an object is created: 
		// - Space is allocated
		// * - Superclass part is constructed 
				// Can't - no default ctor for Book.
		// - Fields constructed
		// - Ctor body runs
		
class Text: public Book {
	...
	public:
		Text(string title, string author, int numPages, string topic): 
		Book{title, author, numPages}, topic {topic}{} // This will work
};
// If superclass has no default constructor, then the subclass must invoke a superclass constructor in it's MIL