// Recall:
class std:unique_ptr<7>

void f() {
	auto p = std::make_unique<MyClass>()
	MyClass mc;
	g();
}

// Difficulty:
class C {...}
unique_ptr<c> p {new C {...}}
unique_ptr<c> q = p;
// We now have 2 unique pointers pointing at the same object
// Both will want to delete c, double free, will probably crash.

// What happens when a unique_ptr is copied? Don't want to delete the same ptr twice
// Instead - copying is disabled for unique ptrs
// They can only be moved
// Ex - when returning a function w/ temp unique_ptr, they will be moved, won't be deleted

// Sample implementation:

template {typename T} class unique_ptr {
	T *ptr;
	public:
		unique_ptr(T *p): ptr {p} {}
		~unique_ptr() {delete ptr;}
		unique_ptr(const unique_ptr<T> &other)=delete; // Prevents copy construction of unique pointers
		unique_ptr<T> &operator=(const unique_ptr &other)=delete;
		unique_ptr(unique_ptr<T> &&other): ptr {other.ptr} {
			other.ptr = nullptr;
		}
		unique_ptr<T> &operator= (unique_ptr<T> &&other) {
			using std::swap;
			swap(ptr, other.ptr);
			return *this;
		}
		T &operator *() {
			return *ptr;
		}
};

// You can use 2 pointers that point to the same thing, make the "owner" ptr the unique_ptr, and the other ones regular ptrs.

// If you need to be able to copy ptr:
std::shared_ptr
randomF() {	auto p1 = std::make_shared<MyClass>();
	if (...) {
		auto p2 = p1;
		// ~p2 popped, ptr is not deleted
	}
	...
} // p1 popped, ptr is deleted

// Shared ptrs maintain a reference count - count of all shared_ptrs pointing at the same object
// Memory is freed when the count hits 0

// Racket Code
(define l1 (cons 1 (cons 2 (cons 3 empty))))
(define l2 (cons 4 (rest l1)))
// In Memory: 1 - 2 - 3
			//	4-^
// Shared tails, don't do this in C++.
// Use shared_ptr & unique_ptr instead of raw ptrs, whenever ownership is intended
// Raw ptrs should mean not owner, unique_ptr sole owner, shared_ptr co-owner
// Dramatically fewer opportunities for leaks

// NEVER let a dtor emit an exception
// dtors run during stack unwinding, when an exp is looking for a handler, 
// if dtor throws exception while one is still looking for handler
// we have 2 unhandled exceptions, against rules of C++ and program ends immediately (Transcribed)
// Actual board notes:
// if the dtor was executed during stack unwinding, while dealing with another exn, you now have two active
// unhandled exns, and the program will abort immediately
// Worst case scenario, catch and do nothing with it

// 3 levels of exception safety for a f'n f:
/* 	1) Basic guarantee - if an exn occurs, the program will be in a valid state. 
	- No leaks, no corruption, class invariants maintained
	2) Strong guarantee - if an exn is raised while executing f, the state of the program will be as if f had not been called
	3) No-throw guarantee - f will never throw an exception, and will always accomplish its task
*/

/x Ex:
class A {...};
class B {...};
class C {
	A a;
	B b;
	void f () {
		a.method1();
		b.method2(); // Both may throw, but offer strong guarantee
	}
};

// Is C::f exception safe?
/* 	- if method1 throws, nothing has happened yet - OK (when it propagates out of f still appears to have done nothing)
	- if method2 throws, effects of method1 would have to be undone to offer the strong guarantee
		- very hard or impossible if method1 has non-local side-effects (Ex: If it prints something to the screen)
	- Therefore, probably not exception safe
	
	If method1 & method2 do not have non-local side-effects, can use copy & swap
*/
class C {
	...
	void f() {
		A atemp = a; // If these throw - f still throws, the original a & b are intact
		B btemp = b;
		atemp.method1(); // If these throw, f still throws but the original a & b are intact
		btemp.method2();
		a = atemp; // But what if these throw?
		b = btemp;
	}
};

// Better if the swap was nothrow - copying ptrs cannot throw
// Solution: use the pImpl idiom

struct CImpl {
	A a;
	B b;
};

class C {
	unique_ptr<CImpl> pImpl;
	...
	void f() { 
		// Strong guarantee 
		auto temp = make_unique<CImpl>(*pImpl);
		temp->a.method1();
		temp->b.method2();
		std::swap(pImpl, temp); // No-throw
	}
};

// If either method1 or method2 isn't exn safe, then neither is f.

// Exception safety & the STL
// vector - encapsulates a heap-allocated array
// - RAII - when a stack-allocated vector goes out of scope, the internal heap array is freed.

void f() {
	vector <MyClass> v;
	...
} // v goes out of scope - array is freed, MyClass dtor runs on all objects in the vector
void g() {
	vector <MyClass *> v;
	...
} // Array is freed, but ptrs don't have dtors, so any objects pointed to by the ptr are NOT deleted

// v doesn't know whether the ptrs in the array own the objs they point at
// If they do, delete them yourself: 
for (auto x: v) delete x; 
// BUT 
void h() {
	vector <shared_ptr<MyClass>> v; // Vector of smart ptrs
	...
} // Array is freed, shared_ptr dtors run, so objs are deleted if no other shared ptr points at them
// No explicit deallocation
// Recall observer pattern, Subject not deleting Observers was correct behaviour, doesn't own them
// If they do, then do the above ^