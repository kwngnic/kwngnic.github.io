// Arrays of Objects
struct Vec {
	int x,y;
	Vec (int x, int y);
};
Vec *vp = new Vec[5]; // Does not compile
Vec moreVecs[3]; // Does not compile
// C++ will not leave an object uninitialized
// Will call default ctor on each item, but there isn't one
// Can't initialize the array items

/* Options: 
1) Provide a default ctor (May initialize certain fields as blank despite being invalid)
2) For stack arrays, Vec moreVecs[] = {{0,0}, {1,3}, {2,4}};
3) For heap arrays: Create an array of pointers:
*/ 
Vec **vp = new Vec*[5];
vp[0] = new Vec{0,0};
vp[1] = new Vec{1,3};
...
for (int i = 0; i < 5; i++) {
	delete vp[i];
}
delete [] vp;

// Const Objects

int f (const Node &n) {...}
// const objects arise often
// What is a const object? Can't change fields
// Can we call methods on a const object?
// Issue: The method may modify fields, violate const
// A: Yes, we can call methods that promise to not change any fields
// Ex:

struct student {
	int assns, mt, final;
	float grade() const; // This method doesn't modify fields
}; // Compiler checks that const methods don't modify fields
// Only const methods can be called on const objects

// Now consider: want to collect usage stats on Student objects:
struct Student {
	...
	int numMethodCalls = 0;
	float grade() const { // This can't compile, grade() can no longer be const.
		++numMethodCalls; // But then can't call grade on const. students
		return ...
	}
};
// But mutating numMethodCalls affects only the physical constness of student objects, not the logical constness.
// Want to be able to update numMethodCalls, even is the object is a constant - declare the field mutable.
struct Student {
	...
	mutable int numMethodCalls = 0;
	float grade() const {
		++numMethodCalls;
		return ...;
	}
}; // mutable fields can be changed even if the object is const

// Static Fields + Methods
// numMethodCalls tracks # of method calls for a particular object. 
// What if we want to track # of method calls over all objects?
// Or what if we want to track how many students are created?
// Static members - associated with the class itself, not with any specific instance (object)

struct Student {
	...
	static int numInstances; // Acts like a global variable, but scoped in the class
	// ^ this is a declaration, need definition
	Student(int assns, int mt, int final): ... {
		++numInstances;
	}
};
int Student::numInstances = 0; // Goes in .cc file
// static fields must be defined external to the class
// Don't have to make it mutable b/c not associated with the class

// Static member functions
// Don't depend on the specific instance (no implicit 'this' parameter)
// Can only access static fields & call other static methods

struct Student {
	...
	static int numInstances;
	...
	static void printNumInstances(){
		cout << numInstances << endl;
	}
};

Student billy {60,70,80};
Student jane {70,80,90};
Student::printNumInstances(); // prints 2

// Invariants & Encapsulation
struct Node {
	int data;
	Node *next;
	Node (int data, Node *next);
	~Node() {delete next;}
};

Node n1 {1, new Node {2, nullptr}};
Node n2 {3, nullptr};
Node n3 {4, &n2};
// What happens when these go out of scope?
// n1 - destructor runs, entire list is deleted
// n2, n3 go out of scope - n3 attempts to delete n2, but n2 is on the stack, not the heap - results in undef behaviour.
// Node relies on an assumption for its proper operation: that next is either nullptr or allocated by new
// This is an invariant - statement that holds true - on which Node relies.
// But we can't guarantee the invariant - can't trust the user to use Node properly
// Can't enforce any invariants, can't control the user
// Ex:

// stack: Invariant - last item pushed is first item popped
// But not if the client can rearrange the underlying batch of data
// Hard to reason about programs if you can't rely on invariants.

// To enforce invariants, we introduce encapsulation
// Want clients to treat objects as black boxes - capsules
// Seal away implementation, interact only via provided methods
// Abstraction - regain control over our objects
// Ex:
struct Vec {
	Vec (int x, int y); // Also public by default
	private: // Can't be accessed outside struct Vec
		int x,y;
	public: // Anyone can access
		Vec operator+(...);
		...
};

// In general, we want fields to be private; only methods should be public
// Better to have default visibility be private
// Switch from struct to class
class Vec {
	int x,y;
	public:
		Vec(int x, int y);
		Vec operator+(...);
		...
};
// Difference between class & struct is the default visibility. (public in struct, private in class)

// Fix the linked list class:
// list.h
class List {
	struct Node; // private nested class, only accessible within class List
	Node *theList = nullptr;
	public:
		void addToFront(int n);
		int ith(int j) const;
		~List() {delete theList;}
};
//list.cc
#include "list.h"
struct List::Node {
	int data;
	Node *next;
	Node(...){}
	~Node(){delete next;}
};

void List::addToFront(int n) {
	theList = new Node {n, theList};
}

void List::ith(int i) const {
	Node *cur = theList;
	for (int n = 0; n < i &&cur; ++n, cur = cur->next);
	return cur->data;
}