// Pure Virtual Methods & Abstract Classes

class Student {
	protected:
		int numCourses;
	public:
		virtual int fees();
};

// 2 kinds of students: Regular and Co-op

class Regular:public Student {
	public:
		int fees() override; // Computes regular students' fees
};

class Coop:public Student {
	public:
		int fees() override; // Computes co=op students' fees
};

// What should we put for Student::fees?
// Not sure - every student should be either regular or coop

// Can explicitly give Student::fees NO implementation
class Student {
	...
	public:
		virtual int fees() = 0; // Method has no implementation (* - partial truth)
		// Called a pure virtual method
};

// A class with a pure virtual method cannot be instantiated
Student s; // Can't do this
// We can use them for things like, array of pointers to student class
// Called an abstract class - purpose is to organize subclasses
// Subclasses of an abstract class are also abstract, unless they implement all pure virtual methods
// Classes that aren't abstract are called concrete

// UML: Virtual & Pure virtual methods: italics
// Abstract classes: class name in italics
// static - underline

// Templates
class List {
	struct Node;
	Node *theList;
	...
};

struct List::Node {
	int data;
	Node *next;
	...
};

// What if you want to store something else? Whole new class?
// OR a template:
// a class parameterized by a type

template <typename T> class Stack {
	int size;
	int cap;
	T *contents; // instead of an array of, say ints, we instead have an array of type T
	public:
		stack() {...}
		void push(T *){...}
		T top() {...}
		void pop(){...}
};

template <typename T> class List {
	struct Node {
		T data;
		Node *next;
	};
	Node *theList;
	public:
		class Iterator {
			Node *p;
			...
		public:
			T &operator*(){return p->data;}
		}; 
		...
		T ith(int i){...}
		void addToFront(T n) {...}
		...
};

// Client
List <int> l1;
List <List <int>> l2;
l1.addToFront(3);
l2.addToFront(l1);
// Iterating
for (List<int>::Iterator it=l1.begin(); it!=l1.end; ++it) {
	cout << *it << endl;
}
// or
for (auto n:l1) { // Also supports range based for loop
	cout << n << endl;
}
// Can have more than 1 typename
// Templates are an exception to declaration in .h
// Can't keep anything secret from compiler, needs to have all details to write the class in .h

// The Standard Template Library (STL)
// Contains a large # of useful templates
// Ex: dynamic-length arrays
// vector
#include <vector>
std::vector<int> v {4,5}; // Creates the vector 4,5 {4,5} has the type std::initializer_list<int>
std::vector<int>w(4,5); // Creates the vector 5,5,5,5

v.emplace_back(6);
v.emplace_back(7); // 4,5,6,7
// Looping:
for (int i = 0; i < v.size(); ++i){
	cout << v[i] << endl;
} // Vectors are guaranteed to be implemented as arrays
// Can use iterator abstraction
for (vector<int>::iterator it = v.begin(); it!= v.end(); ++it) { // iterator starts w/ smaller i for vectors
	cout << *it << endl;
}
// Can still use range based for loop
for (auto n:v){
	cout << n << endl;
}
// To iterate in reverse:
for (vector<int>::reverse_iterator it=v.rbegin(); it != v.rend(); ++it) {
	cout << *it << endl;
} // can still replace vector<int>::reverse_iterator with auto
v.pop_back(); // removes last element
// Most things in STL make use of iterators
// Use itertors to remove items from inside a vector
auto it = v.erase(v.begin()); // Erases first item (item 0)
it = v.erase(v.begin() + 3); // Erases item 3
// Not all iterators can do this but for vectors you can

// Returns an iterator to the first item after the erase
it = v.erase(it); // If repeated would eventually erase the whole array
// use a for loop, it = v.end() basically
// iterators don't type check
it = v.erase(v.end() - 1); // last item

v[i] // -ith element of v
// unchecked - if you go out of bounds, you get undefined behaviour
v.at(i) // checked version of v[i]
// What happens if you go out of bounds?
// What should happen?
// Problem: vector's code can detect the error, but doesn't know what to do about it
// client can respond, but can't detect the error

// C solution: functions return a status code, or set the global variable errno
// Leads to awkward programming where you wrap every function call in an if statement or check global variable everytime
// Encourages programmers to ignore error checks

// C++
// When an error condition arises, the function raises an exception
// What happens? - by default, execution stops
// But, we can write handlers to catch execeptions and deal with them
vector<t>::at // raises the exception std::out_of_range
// We handle as follows:
#include <stdexcept>
...
try { // statements that may fail go into a try block
	cout << v.at(10000)<<endl;
} 
catch (out_of_range){ // out_of_range is a type (exception), r is the object itself
	cerr << "Range error" << endl;
}
// or
catch (out_of_range r) {
	cerr << "Range error" << r.what() << endl;; // Still prints same error as in the pervious out of range example, but otherwise wouldn't print
	// Then goes ahead and finishes the program (see git repo)
}