// Visitor Pattern

/*
[<i>Enemy</i>]					[<i>Weapon</i>]
	^								^
Inherits						Inherits
	|_______						|
	|		|					____|____
[Turtle]	[Bullet]			|		|
							[Stick]		[Rock]
*/

// Effect of stiking Enemy with Weapon depends on both the Enemy and the Weapon
// We want:
virtual void(Enemy, Weapon)::strike(); // This will not work, we need virtual method to be in a class

// If strike is in Enemy, effect will depend on the Enemy, but not the Weapon
// If it is in Weapon, effect will depend on the Weapon, but not on the Enemy
// Trick to get dispatch based on both (double dispatch) - combine overriding with overloading

class Enemy {
	virtual void beStruckBy(Weapon &w) = 0;
};

class Turtle: public Enemy {
	void beStruckBy(Weapon &w) override {
		w.strike(*this);
	}
};

class Bullet: public Enemy {
	void beStruckBy(Weapon &w) override {
		w.strike(*this);
	}
};
// Turtle and Bullet seem to have same body, so why 
// not put it in weapon and save the override, but the body is not the same despite looking like they are
// They differ in the type of *this, one is a Bullet, and the other is a Turtle
// Calling Turtle/Bullet version of strike, two different types of overloads

class Weapon {
	virtual void strike(Turtle &t) = 0; // This two are overloads
	virtual void strike(Bullet &b) = 0;
};

class Stick: public Weapon {
	void strike(Turtle &t) override {
		// strike turtle with stick
	}
	void strike(Bullet &b) override {
		// strike bullet with stick
	}
};
// Same thing as above for Rock class

Enemy *e = new Bullet {...};
Weapon *w = new Rock {...};
e->beStruckBy(*w); // What happens?
// beStruckBy is virtual
Bullet::beStruckBy // calls Weapon::strike, *this is a Bullet
// So this resolves at compile-time, to 
Weapon::strike(Bullet &)
// strike is virtual
// resolves to 
Rock::strike(Bullet &)

// Visitor can be used to add functionality to existing classes, without changing or recompiling them
// Ex: add a visitor to the Book hierarchy
class Book { // Similar to Enemy
	public:
		virtual void accept(BookVisitor &v){ // Similar to beStruckBy
			v.visit(*this); // Similar to strike
		}
};

class Text: public Book {
	public:
		void accept(BookVisitor &v) override {
			v.visit(*this);
		}
};
// Comic will be the same, etc.
class BookVisitor { // Similar to Weapon
	public:
		virtual void visit (Book &b) = 0;
		virtual void visit (Text &t) = 0;
		virtual void visit (comic &c) = 0;
};

// Application: Track how many of each type of Book I have:
// Books - by Author
// Texts - by topic
// Comics - by hero

// Use a map<string, int>
// Could add a virtual void updateMap(){...}
// Or write a visitor:
class Catalogue: public BookVisitor {
	map <string, int> theCatalogue;
	public:
		map <string, int> getResult() {
			return theCatalogue;
		}
		void visit(Book &b) override {
			++theCatalogue[b.getAuthor()];
		}
		void visit(Text &t) override {
			++theCatalogue[t.getTopic()];
		}
		void visit(Comic &c) override {
			++theCatalogue[c.getHero()];
		}
};

// BookVisitor example won't compile - why?
// Why can't Text see that there is a book class to inherit from?
// main.cc includes book.h, includes BookVisitor.h, includes Text.h, includes book.h <- last book inclusion doesn't happen b/c include guard
// Text is now above book, doesn't inherit from it
// Are these includes really needed?

// Compilation Dependencies - include vs forward declare
// Consider:
class A {...};

// B inherits all of A's fields, so we need to know A's size
#include "a.h"
class B: public A {
	...
};

#include "a.h" // We need to know enough about A to know it's size
class C {
	A myA;
};

class A; // Forward declaring, D only requires a pointer, don't need to fill A
// Also, pointers have the same size, need to know nothing about class A
class D {
	A *myA;
};

class A; // Don't need to know A's size
class E {
	A f(A x);
};
// Don't introduce extra compilation dependencies by unneeded #includes
// Now in the implementations of D, E:
// d.cc
#include "a.h"
void D::f() {
	myAp->someMethod(); // Real compilation dependency, need to know A's methods
}
// Do the #include in the .cc, instead of the .h (where possible)
// Impossible to get #include cycles in .cc files, because you never include .cc files, so they will never participate in a cycle
// Now consider the XWindow class:
class XWindow {
	Display *d;
	Window w;
	int s;
	GC gc;
	unsigned long colours[10]; // This is private data, yet we can look at it
	// Do we know what it all means - do we care?
	public:
		...
};

// If we add or change a private member - all clients must recompile
// Would be better to hide these details away
// Sol'n: pimpl idiom ("pointer to implementation")
// Create a second class XWindowImpl:
// XWindowImpl.h
#include <X11/Xlib.h>
struct XWindowImpl{
	Display *d
	Window w;
	int s;
	GC gc;
	unsigned long colours[10];
};

// Window.h
class XWindowImpl;
class XWindow {
	XWindowImpl *pImpl;
	public:
		// Etc, no change
};
// No need to include Xlib.h
// forward declare the Impl class
// No compilation dependency on XWindowImpl.h
// Clients also don't depend on XWindowImpl.h

// Window.cc
#include "window.h"
#include "XWindowImpl.h"
XWindow::XWindow(...):
	pImpl{new XWindowImpl{...}}{}
	// Other methods: replace fields d,w,s, etc. with 
	pImpl->d;
	pImpl->w;
	pImpl->s; // etc.
// If all private fields are in XWindowImpl, then only Window.cc needs recompling if you change XWindow's implementation

// Generalization - What if there are several possible window implementations, say XWindow + YWindow
// Then make the Impl struct a superclass:
/* <> = filled in
			(ptr) Want to say that it's a ptr here
[Window]<>------>[WindowImpl]
			pImpl	^
					Inherits
					|
				____|____________
				|				|
			[XWindowImpl]	[YWindowInput]
*/ 
// pImpl + subclassing: called the Bridge Pattern